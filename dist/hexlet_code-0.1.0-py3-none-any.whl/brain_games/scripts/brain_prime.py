from brain_games.games.prime import prime_game


def main():
    prime_game()


if __name__ == "__name__":
    main()
