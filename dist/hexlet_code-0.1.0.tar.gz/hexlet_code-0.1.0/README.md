### Hexlet tests and linter status:
[![Actions Status](https://github.com/Evgenii-Prokofev/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Evgenii-Prokofev/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/cfbc883db93da7bd875a/maintainability)](https://codeclimate.com/github/Evgenii-Prokofev/python-project-49/maintainability)
https://asciinema.org/a/z1X22ZosOacantNkaNOQLyZct
