### Hexlet tests and linter status:
[![Actions Status](https://github.com/Evgenii-Prokofev/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Evgenii-Prokofev/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/cfbc883db93da7bd875a/maintainability)](https://codeclimate.com/github/Evgenii-Prokofev/python-project-49/maintainability)
https://asciinema.org/a/z1X22ZosOacantNkaNOQLyZct
https://asciinema.org/a/XfuCQdzEX8W02mTy1pRJzrzRy
https://asciinema.org/a/hleXcPlUGJx6ivnZltfWCKrM2
https://asciinema.org/a/PaMJzR7Akx7ntplzasvR1Zl8P
 https://asciinema.org/a/ioRQB2rfhuPd81gVk4VBpYc5x
