from brain_games.games.calc import calc_game


def main():
    calc_game()



if __name__ == "__name__":
    main()


